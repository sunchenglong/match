package templatematch;

public abstract class MatchStrategy {
	
	 public abstract MatchResult matchalgorithmInterface(ImageObj imgobj);

}
